//package QuistAssignment1;

public class golfClub {
   String clubType;
   int clubNumber;

   /**
    * golfBag() Constructor for golfBag class
    * @param s Name of the golf club
    * @param n Number of the golf club
    */
   public golfClub(String s, int n) {
      clubType = s;
      this.clubNumber = n;
   }

   /**
    * getClubType()
    * @return the club type of the object. 
    */
   public String getClubType() {
      return this.clubType;
   }

   /**
    * getClubNumber()
    * @return the club number of the object. 
    */
   public int getClubNumber() {
      return this.clubNumber;
   }

   /**
    * setClubType()
    * @param clubType set the club type of the object 
    */
   public void setClubType(String clubType) {
      this.clubType = clubType;
   }

   /**
    * setClubNumber()
    * @param clubNumber sets the club number of the object.
    */
   public void setClubNumber(int clubNumber) {
      this.clubNumber = clubNumber;
   }

   /**
    * toString()
    * @return returns the club type and club number of the object as a String object. 
    */
   public String toString() {
      return this.clubType + "\t" + this.clubNumber;
   }

   /**
    * equals() 
    * @param o golfBag object to check against object the method was called on. 
    * @return boolean true or false if equal or not equal respectively. 
    */
   public boolean equals(golfClub o) {
      if (o instanceof golfClub) {
         return o.clubType.equalsIgnoreCase(this.clubType) && o.clubNumber == this.clubNumber;
      } else {
         return false;
      }
   }
}
